import React from 'react';
import { useGame } from './hooks/useGame';
import { Header } from './components/Header';
import { StartScreen } from './components/StartScreen';
import { GameStatus } from './components/GameStatus';
import { GameBoard } from './components/GameBoard';
import { ScoreBoard } from './components/ScoreBoard';
import { GameControls } from './components/GameControls';
import { Confetti } from './components/Confetti';
import { Footer } from './components/Footer';
import { MatchSummaryModal } from './components/MatchSummaryModal';
import { ReplayModal } from './components/ReplayModal';
import { SettingsModal } from './components/SettingsModal';
import { StatsModal } from './components/StatsModal';
import { HowToPlayModal } from './components/HowToPlayModal';
import { Toast } from './components/Toast';
import './App.css';

export const App: React.FC = () => {
  const {
    inGame,
    setInGame,
    gameMode,
    boardSize,
    matchSeries,
    isAiThinking,
    p1,
    p2,
    board,
    currentPlayer,
    winner,
    winningCells,
    winningCoords,
    isDraw,
    seriesScores,
    moveHistory,
    lastGameMoves,
    timeLeft,
    timerDuration,
    matchDuration,
    hintCell,
    invalidCell,

    showMatchSummary,
    setShowMatchSummary,
    showReplayModal,
    setShowReplayModal,
    showSettingsModal,
    setShowSettingsModal,
    showStatsModal,
    setShowStatsModal,
    showHowToPlayModal,
    setShowHowToPlayModal,
    toastMessage,
    showToast,

    settings,
    updateSettings,
    overallStats,
    gameHistory,
    leaderboard,

    makeMove,
    startGame,
    rematch,
    undoMove,
    requestHint,
    resetAllData,
  } = useGame();

  const isGameOver = winner !== null || isDraw;

  return (
    <div className="app-container">
      <Confetti active={winner !== null} />
      <Toast message={toastMessage} />

      <div className="game-card">
        <Header
          inGame={inGame}
          settings={settings}
          onUpdateSettings={updateSettings}
          onOpenSettings={() => setShowSettingsModal(true)}
          onOpenStats={() => setShowStatsModal(true)}
          onOpenHowToPlay={() => setShowHowToPlayModal(true)}
          onBackToLobby={() => setInGame(false)}
        />

        {!inGame ? (
          <StartScreen
            onStart={startGame}
            onOpenStats={() => setShowStatsModal(true)}
            onOpenHowToPlay={() => setShowHowToPlayModal(true)}
          />
        ) : (
          <>
            <GameStatus
              currentPlayer={currentPlayer}
              winner={winner}
              isDraw={isDraw}
              isAiThinking={isAiThinking}
              p1={p1}
              p2={p2}
              timeLeft={timeLeft}
              timerDuration={timerDuration}
              matchSeries={matchSeries}
              seriesScores={seriesScores}
            />

            <GameBoard
              board={board}
              boardSize={boardSize}
              winningCells={winningCells}
              winningCoords={winningCoords}
              hintCell={hintCell}
              invalidCell={invalidCell}
              disabled={isGameOver || isAiThinking}
              p1={p1}
              p2={p2}
              onCellClick={makeMove}
            />

            <ScoreBoard
              p1={p1}
              p2={p2}
              seriesScores={seriesScores}
              overallStats={overallStats}
              currentPlayer={currentPlayer}
              gameOver={isGameOver}
              gameMode={gameMode}
            />

            <GameControls
              canUndo={moveHistory.length > 0}
              onUndo={undoMove}
              onHint={requestHint}
              onRematch={rematch}
              onReplay={() => setShowReplayModal(true)}
              hasReplay={lastGameMoves.length > 0}
              gameEnded={isGameOver}
            />
          </>
        )}

        <Footer />
      </div>

      <MatchSummaryModal
        isOpen={showMatchSummary}
        onClose={() => setShowMatchSummary(false)}
        winner={winner || 'draw'}
        p1={p1}
        p2={p2}
        board={board}
        boardSize={boardSize}
        movesCount={lastGameMoves.length || moveHistory.length}
        durationSeconds={matchDuration}
        onRematch={rematch}
        onWatchReplay={() => setShowReplayModal(true)}
        onShowToast={showToast}
      />

      <ReplayModal
        isOpen={showReplayModal}
        onClose={() => setShowReplayModal(false)}
        boardSize={boardSize}
        moves={lastGameMoves.length > 0 ? lastGameMoves : moveHistory}
        p1={p1}
        p2={p2}
      />

      <SettingsModal
        isOpen={showSettingsModal}
        onClose={() => setShowSettingsModal(false)}
        settings={settings}
        onUpdateSettings={updateSettings}
        onResetAllData={resetAllData}
      />

      <StatsModal
        isOpen={showStatsModal}
        onClose={() => setShowStatsModal(false)}
        overallStats={overallStats}
        history={gameHistory}
        leaderboard={leaderboard}
      />

      <HowToPlayModal
        isOpen={showHowToPlayModal}
        onClose={() => setShowHowToPlayModal(false)}
      />
    </div>
  );
};

export default App;
