import { useState, useEffect, useCallback } from 'react';
import type {
  Board,
  BoardSize,
  GameMode,
  AIDifficulty,
  MatchSeries,
  TimerDuration,
  Player,
  PlayerProfile,
  MoveRecord,
  GameHistoryItem,
  PlayerStats,
  LeaderboardEntry,
  GameSettings,
  WinResult,
} from '../types/game';
import { createInitialBoard, checkWinner, checkDraw } from '../utils/gameLogic';
import { getBestAIMove, getHintMove } from '../utils/ai';
import { sound } from '../utils/sound';

export const AVATAR_OPTIONS = ['🤖', '⚡', '👑', '🔥', '🐱', '🧙‍♂️', '🥷', '🚀', '⭐', '💎'];
export const COLOR_OPTIONS = [
  '#2563EB',
  '#DC2626',
  '#059669',
  '#7C3AED',
  '#D97706',
  '#0284C7',
  '#DB2777',
  '#EA580C',
];

const DEFAULT_SETTINGS: GameSettings = {
  theme: 'classic-blue',
  darkMode: false,
  timerDuration: 0,
  soundEnabled: true,
  aiDifficulty: 'hard',
  boardSize: 3,
  series: 1,
};

export function useGame() {
  const [inGame, setInGame] = useState<boolean>(false);
  const [gameMode, setGameMode] = useState<GameMode>('pvp');
  const [boardSize, setBoardSize] = useState<BoardSize>(3);
  const [matchSeries, setMatchSeries] = useState<MatchSeries>(1);
  const [aiDifficulty, setAiDifficulty] = useState<AIDifficulty>('hard');
  const [isAiThinking, setIsAiThinking] = useState<boolean>(false);

  const [p1, setP1] = useState<PlayerProfile>({
    name: 'Player 1',
    marker: 'X',
    avatar: '👑',
    color: '#2563EB',
  });

  const [p2, setP2] = useState<PlayerProfile>({
    name: 'Player 2',
    marker: 'O',
    avatar: '⚡',
    color: '#0284C7',
  });

  const [board, setBoard] = useState<Board>(createInitialBoard(3));
  const [currentPlayer, setCurrentPlayer] = useState<Player>('X');
  const [startingPlayer, setStartingPlayer] = useState<Player>('X');
  const [winner, setWinner] = useState<Player | null>(null);
  const [winningCells, setWinningCells] = useState<number[]>([]);
  const [winningCoords, setWinningCoords] = useState<{ x1: number; y1: number; x2: number; y2: number } | undefined>(undefined);
  const [isDraw, setIsDraw] = useState<boolean>(false);

  const [seriesScores, setSeriesScores] = useState<{ X: number; O: number; draws: number }>({
    X: 0,
    O: 0,
    draws: 0,
  });

  const [moveHistory, setMoveHistory] = useState<MoveRecord[]>([]);
  const [lastGameMoves, setLastGameMoves] = useState<MoveRecord[]>([]);

  const [timeLeft, setTimeLeft] = useState<number>(0);
  const [matchStartTime, setMatchStartTime] = useState<number>(0);
  const [matchDuration, setMatchDuration] = useState<number>(0);

  const [hintCell, setHintCell] = useState<number | null>(null);
  const [invalidCell, setInvalidCell] = useState<number | null>(null);

  const [showMatchSummary, setShowMatchSummary] = useState<boolean>(false);
  const [showReplayModal, setShowReplayModal] = useState<boolean>(false);
  const [showSettingsModal, setShowSettingsModal] = useState<boolean>(false);
  const [showStatsModal, setShowStatsModal] = useState<boolean>(false);
  const [showHowToPlayModal, setShowHowToPlayModal] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const [settings, setSettings] = useState<GameSettings>(() => {
    try {
      const saved = localStorage.getItem('olayode_daniel_ttt_settings');
      if (saved) return { ...DEFAULT_SETTINGS, ...JSON.parse(saved) };
    } catch {}
    return DEFAULT_SETTINGS;
  });

  const [overallStats, setOverallStats] = useState<{
    p1: PlayerStats;
    p2: PlayerStats;
    ai: PlayerStats;
  }>(() => {
    try {
      const saved = localStorage.getItem('olayode_daniel_ttt_stats');
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      p1: { wins: 0, losses: 0, draws: 0, currentStreak: 0, bestStreak: 0 },
      p2: { wins: 0, losses: 0, draws: 0, currentStreak: 0, bestStreak: 0 },
      ai: { wins: 0, losses: 0, draws: 0, currentStreak: 0, bestStreak: 0 },
    };
  });

  const [gameHistory, setGameHistory] = useState<GameHistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('olayode_daniel_ttt_history');
      if (saved) return JSON.parse(saved);
    } catch {}
    return [];
  });

  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>(() => {
    try {
      const saved = localStorage.getItem('olayode_daniel_ttt_leaderboard');
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      { name: 'Olayode Daniel', avatar: '👑', wins: 12, matches: 15, winRate: 80, bestStreak: 7 },
      { name: 'Master AI', avatar: '🤖', wins: 8, matches: 12, winRate: 67, bestStreak: 4 },
      { name: 'Speedy Ninja', avatar: '🥷', wins: 5, matches: 9, winRate: 56, bestStreak: 3 },
    ];
  });

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 2800);
  }, []);

  const updateSettings = useCallback((newSettings: Partial<GameSettings>) => {
    setSettings((prev) => {
      const updated = { ...prev, ...newSettings };
      try {
        localStorage.setItem('olayode_daniel_ttt_settings', JSON.stringify(updated));
      } catch {}
      if (newSettings.soundEnabled !== undefined) {
        sound.enabled = newSettings.soundEnabled;
      }
      return updated;
    });
  }, []);

  useEffect(() => {
    sound.enabled = settings.soundEnabled;
  }, [settings.soundEnabled]);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', settings.theme);
    if (settings.darkMode) {
      document.documentElement.classList.add('dark-mode');
    } else {
      document.documentElement.classList.remove('dark-mode');
    }
  }, [settings.theme, settings.darkMode]);

  const handleGameEnd = useCallback(
    (winResult: WinResult, isDrawGame: boolean, moves: MoveRecord[]) => {
      const duration = Math.round((Date.now() - matchStartTime) / 1000);
      setMatchDuration(duration);
      setLastGameMoves([...moves]);

      const winningPlayer = winResult.winner;
      const winnerName = winningPlayer
        ? winningPlayer === p1.marker
          ? p1.name
          : p2.name
        : 'Draw';

      if (winningPlayer) {
        setSeriesScores((prev) => ({
          ...prev,
          [winningPlayer]: prev[winningPlayer] + 1,
        }));
      } else if (isDrawGame) {
        setSeriesScores((prev) => ({
          ...prev,
          draws: prev.draws + 1,
        }));
      }

      setOverallStats((prev) => {
        const next = { ...prev };
        if (winningPlayer === p1.marker) {
          next.p1.wins += 1;
          next.p1.currentStreak += 1;
          next.p1.bestStreak = Math.max(next.p1.bestStreak, next.p1.currentStreak);

          if (gameMode === 'ai') {
            next.ai.losses += 1;
            next.ai.currentStreak = 0;
          } else {
            next.p2.losses += 1;
            next.p2.currentStreak = 0;
          }
        } else if (winningPlayer === p2.marker) {
          if (gameMode === 'ai') {
            next.ai.wins += 1;
            next.ai.currentStreak += 1;
            next.ai.bestStreak = Math.max(next.ai.bestStreak, next.ai.currentStreak);
          } else {
            next.p2.wins += 1;
            next.p2.currentStreak += 1;
            next.p2.bestStreak = Math.max(next.p2.bestStreak, next.p2.currentStreak);
          }
          next.p1.losses += 1;
          next.p1.currentStreak = 0;
        } else if (isDrawGame) {
          next.p1.draws += 1;
          if (gameMode === 'ai') next.ai.draws += 1;
          else next.p2.draws += 1;
        }

        try {
          localStorage.setItem('olayode_daniel_ttt_stats', JSON.stringify(next));
        } catch {}
        return next;
      });

      const historyItem: GameHistoryItem = {
        id: 'match_' + Date.now(),
        date: new Date().toLocaleDateString(undefined, {
          month: 'short',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
        }),
        mode: gameMode,
        boardSize,
        winner: winningPlayer || 'draw',
        winnerName,
        p1: { ...p1 },
        p2: { ...p2 },
        movesCount: moves.length,
        durationSeconds: duration,
      };

      setGameHistory((prev) => {
        const updated = [historyItem, ...prev.slice(0, 49)];
        try {
          localStorage.setItem('olayode_daniel_ttt_history', JSON.stringify(updated));
        } catch {}
        return updated;
      });

      if (winningPlayer) {
        setLeaderboard((prev) => {
          const list = [...prev];
          const winnerProf = winningPlayer === p1.marker ? p1 : p2;
          const idx = list.findIndex((e) => e.name.toLowerCase() === winnerProf.name.toLowerCase());
          if (idx >= 0) {
            list[idx].wins += 1;
            list[idx].matches += 1;
            list[idx].winRate = Math.round((list[idx].wins / list[idx].matches) * 100);
            list[idx].avatar = winnerProf.avatar;
          } else {
            list.push({
              name: winnerProf.name,
              avatar: winnerProf.avatar,
              wins: 1,
              matches: 1,
              winRate: 100,
              bestStreak: 1,
            });
          }
          list.sort((a, b) => b.wins - a.wins || b.winRate - a.winRate);
          try {
            localStorage.setItem('olayode_daniel_ttt_leaderboard', JSON.stringify(list));
          } catch {}
          return list;
        });
      }

      setTimeout(() => {
        setShowMatchSummary(true);
      }, 1000);
    },
    [matchStartTime, p1, p2, gameMode, boardSize]
  );

  const makeMove = useCallback(
    (index: number) => {
      if (
        board[index] !== null ||
        winner !== null ||
        isDraw ||
        isAiThinking
      ) {
        if (board[index] !== null) {
          sound.playInvalid();
          setInvalidCell(index);
          setTimeout(() => setInvalidCell(null), 400);
        }
        return;
      }

      setHintCell(null);
      const player = currentPlayer;
      sound.playMove(player);

      const nextBoard = [...board];
      nextBoard[index] = player;

      const newMoveRecord: MoveRecord = {
        index,
        player,
        timestamp: Date.now(),
      };
      const nextMoves = [...moveHistory, newMoveRecord];
      setMoveHistory(nextMoves);

      const winResult = checkWinner(nextBoard, boardSize);
      const drawResult = checkDraw(nextBoard, winResult.winner);

      setBoard(nextBoard);

      if (winResult.winner) {
        sound.playWin();
        setWinner(winResult.winner);
        setWinningCells(winResult.winningCells);
        setWinningCoords(winResult.lineCoords);
        handleGameEnd(winResult, false, nextMoves);
      } else if (drawResult) {
        sound.playDraw();
        setIsDraw(true);
        handleGameEnd(winResult, true, nextMoves);
      } else {
        const nextPlayer = player === 'X' ? 'O' : 'X';
        setCurrentPlayer(nextPlayer);
        if (settings.timerDuration > 0) {
          setTimeLeft(settings.timerDuration);
        }
      }
    },
    [board, winner, isDraw, isAiThinking, currentPlayer, moveHistory, boardSize, settings.timerDuration, handleGameEnd]
  );

  useEffect(() => {
    if (
      !inGame ||
      gameMode !== 'ai' ||
      winner !== null ||
      isDraw ||
      currentPlayer !== p2.marker ||
      isAiThinking
    ) {
      return;
    }

    setIsAiThinking(true);
    const thinkTime = 400 + Math.random() * 250;

    const timer = setTimeout(() => {
      const bestMove = getBestAIMove(board, boardSize, p2.marker, aiDifficulty);
      setIsAiThinking(false);
      if (bestMove !== -1) {
        makeMove(bestMove);
      }
    }, thinkTime);

    return () => clearTimeout(timer);
  }, [inGame, gameMode, winner, isDraw, currentPlayer, p2.marker, board, boardSize, aiDifficulty, isAiThinking, makeMove]);

  useEffect(() => {
    if (!inGame || winner !== null || isDraw || settings.timerDuration === 0) return;

    if (timeLeft <= 0) {
      const emptyIdxs: number[] = [];
      board.forEach((val, idx) => {
        if (val === null) emptyIdxs.push(idx);
      });
      if (emptyIdxs.length > 0) {
        const timeoutMove = emptyIdxs[Math.floor(Math.random() * emptyIdxs.length)];
        showToast(`⏰ Time's up! Auto move made for ${currentPlayer}.`);
        makeMove(timeoutMove);
      }
      return;
    }

    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev === 4 || prev === 3 || prev === 2) {
          sound.playTimerTick();
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [inGame, winner, isDraw, settings.timerDuration, timeLeft, board, currentPlayer, makeMove, showToast]);

  const startGame = useCallback(
    (
      mode: GameMode,
      size: BoardSize,
      series: MatchSeries,
      diff: AIDifficulty,
      player1: PlayerProfile,
      player2: PlayerProfile,
      chosenTimer: TimerDuration
    ) => {
      sound.playClick();
      setGameMode(mode);
      setBoardSize(size);
      setMatchSeries(series);
      setAiDifficulty(diff);
      setP1(player1);
      setP2(player2);
      updateSettings({
        boardSize: size,
        series,
        aiDifficulty: diff,
        timerDuration: chosenTimer,
      });

      const initial = createInitialBoard(size);
      setBoard(initial);
      setCurrentPlayer('X');
      setStartingPlayer('X');
      setWinner(null);
      setWinningCells([]);
      setWinningCoords(undefined);
      setIsDraw(false);
      setMoveHistory([]);
      setSeriesScores({ X: 0, O: 0, draws: 0 });
      setMatchStartTime(Date.now());
      if (chosenTimer > 0) setTimeLeft(chosenTimer);
      setShowMatchSummary(false);
      setInGame(true);
    },
    [updateSettings]
  );

  const rematch = useCallback(() => {
    sound.playClick();
    const nextStart = startingPlayer === 'X' ? 'O' : 'X';
    setStartingPlayer(nextStart);
    setCurrentPlayer(nextStart);
    setBoard(createInitialBoard(boardSize));
    setWinner(null);
    setWinningCells([]);
    setWinningCoords(undefined);
    setIsDraw(false);
    setMoveHistory([]);
    setHintCell(null);
    setMatchStartTime(Date.now());
    if (settings.timerDuration > 0) setTimeLeft(settings.timerDuration);
    setShowMatchSummary(false);
  }, [startingPlayer, boardSize, settings.timerDuration]);

  const undoMove = useCallback(() => {
    if (moveHistory.length === 0 || winner !== null || isDraw || isAiThinking) return;

    sound.playUndo();
    const stepsToUndo = gameMode === 'ai' && moveHistory.length >= 2 ? 2 : 1;
    const newHistory = moveHistory.slice(0, moveHistory.length - stepsToUndo);

    const reconstructedBoard = createInitialBoard(boardSize);
    newHistory.forEach((m) => {
      reconstructedBoard[m.index] = m.player;
    });

    setBoard(reconstructedBoard);
    setMoveHistory(newHistory);
    setWinner(null);
    setWinningCells([]);
    setWinningCoords(undefined);
    setIsDraw(false);
    setHintCell(null);

    const nextTurn =
      newHistory.length === 0
        ? startingPlayer
        : newHistory[newHistory.length - 1].player === 'X'
        ? 'O'
        : 'X';
    setCurrentPlayer(nextTurn);
    if (settings.timerDuration > 0) setTimeLeft(settings.timerDuration);

    showToast('↩️ Move undone!');
  }, [moveHistory, winner, isDraw, isAiThinking, gameMode, boardSize, startingPlayer, settings.timerDuration, showToast]);

  const requestHint = useCallback(() => {
    if (winner !== null || isDraw || isAiThinking) return;
    const hint = getHintMove(board, boardSize, currentPlayer);
    if (hint !== -1) {
      sound.playHint();
      setHintCell(hint);
      showToast(`💡 Hint: Try cell ${hint + 1}!`);
      setTimeout(() => {
        setHintCell(null);
      }, 3500);
    }
  }, [board, boardSize, currentPlayer, winner, isDraw, isAiThinking, showToast]);

  const resetAllData = useCallback(() => {
    sound.playClick();
    const cleanStats = {
      p1: { wins: 0, losses: 0, draws: 0, currentStreak: 0, bestStreak: 0 },
      p2: { wins: 0, losses: 0, draws: 0, currentStreak: 0, bestStreak: 0 },
      ai: { wins: 0, losses: 0, draws: 0, currentStreak: 0, bestStreak: 0 },
    };
    setOverallStats(cleanStats);
    setGameHistory([]);
    setLeaderboard([]);
    try {
      localStorage.removeItem('olayode_daniel_ttt_stats');
      localStorage.removeItem('olayode_daniel_ttt_history');
      localStorage.removeItem('olayode_daniel_ttt_leaderboard');
    } catch {}
    showToast('🧹 All statistics & match history cleared!');
  }, [showToast]);

  return {
    inGame,
    setInGame,
    gameMode,
    boardSize,
    matchSeries,
    aiDifficulty,
    isAiThinking,
    p1,
    p2,
    board,
    currentPlayer,
    winner,
    winningCells,
    winningCoords,
    isDraw,
    seriesScores,
    moveHistory,
    lastGameMoves,
    timeLeft,
    timerDuration: settings.timerDuration,
    matchDuration,
    hintCell,
    invalidCell,

    showMatchSummary,
    setShowMatchSummary,
    showReplayModal,
    setShowReplayModal,
    showSettingsModal,
    setShowSettingsModal,
    showStatsModal,
    setShowStatsModal,
    showHowToPlayModal,
    setShowHowToPlayModal,
    toastMessage,
    showToast,

    settings,
    updateSettings,
    overallStats,
    gameHistory,
    leaderboard,

    makeMove,
    startGame,
    rematch,
    undoMove,
    requestHint,
    resetAllData,
  };
}
