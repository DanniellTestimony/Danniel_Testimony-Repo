export type Player = 'X' | 'O';
export type CellValue = Player | null;
export type Board = CellValue[];

export type BoardSize = 3 | 4 | 5;
export type GameMode = 'pvp' | 'ai';
export type AIDifficulty = 'easy' | 'medium' | 'hard';
export type MatchSeries = 1 | 3 | 5; // Single game, Best of 3, Best of 5
export type ThemeId = 'classic-blue' | 'neon-cyberpunk' | 'dark-minimal' | 'emerald-forest' | 'sunset-glow';
export type TimerDuration = 0 | 5 | 10 | 15 | 30; // 0 = Off

export interface PlayerProfile {
  name: string;
  marker: Player;
  avatar: string;
  color: string;
}

export interface MoveRecord {
  index: number;
  player: Player;
  timestamp: number;
}

export interface GameHistoryItem {
  id: string;
  date: string;
  mode: GameMode;
  boardSize: BoardSize;
  winner: Player | 'draw';
  winnerName: string;
  p1: PlayerProfile;
  p2: PlayerProfile;
  movesCount: number;
  durationSeconds: number;
}

export interface PlayerStats {
  wins: number;
  losses: number;
  draws: number;
  currentStreak: number;
  bestStreak: number;
}

export interface LeaderboardEntry {
  name: string;
  avatar: string;
  wins: number;
  matches: number;
  winRate: number;
  bestStreak: number;
}

export interface GameSettings {
  theme: ThemeId;
  darkMode: boolean;
  timerDuration: TimerDuration;
  soundEnabled: boolean;
  aiDifficulty: AIDifficulty;
  boardSize: BoardSize;
  series: MatchSeries;
}

export interface WinResult {
  winner: Player | null;
  winningCells: number[];
  lineCoords?: { x1: number; y1: number; x2: number; y2: number };
}
