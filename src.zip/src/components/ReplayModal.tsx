import React, { useState, useEffect } from 'react';
import type { BoardSize, MoveRecord, PlayerProfile } from '../types/game';
import { createInitialBoard } from '../utils/gameLogic';
import { Play, Pause, RotateCcw, ChevronLeft, ChevronRight, X } from 'lucide-react';

interface ReplayModalProps {
  isOpen: boolean;
  onClose: () => void;
  boardSize: BoardSize;
  moves: MoveRecord[];
  p1: PlayerProfile;
  p2: PlayerProfile;
}

export const ReplayModal: React.FC<ReplayModalProps> = ({
  isOpen,
  onClose,
  boardSize,
  moves,
  p1,
  p2,
}) => {
  const [step, setStep] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [speed, setSpeed] = useState<1 | 2>(1);

  useEffect(() => {
    if (isOpen) {
      setStep(0);
      setIsPlaying(true);
    }
  }, [isOpen]);

  useEffect(() => {
    if (!isPlaying) return;
    if (step >= moves.length) {
      setIsPlaying(false);
      return;
    }

    const interval = setInterval(() => {
      setStep((prev) => {
        if (prev >= moves.length) {
          setIsPlaying(false);
          return prev;
        }
        return prev + 1;
      });
    }, 800 / speed);

    return () => clearInterval(interval);
  }, [isPlaying, step, moves.length, speed]);

  if (!isOpen) return null;

  // Build board up to current step
  const replayBoard = createInitialBoard(boardSize);
  for (let i = 0; i < step; i++) {
    const m = moves[i];
    if (m) replayBoard[m.index] = m.player;
  }

  const lastMoveIndex = step > 0 && step <= moves.length ? moves[step - 1].index : -1;

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-content replay-modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h3 className="modal-title">🎬 Game Replay</h3>
          <button type="button" className="modal-close-btn" onClick={onClose} aria-label="Close">
            <X size={18} />
          </button>
        </div>

        <div className="replay-status">
          <span>
            Move {step} of {moves.length}
          </span>
        </div>

        {/* Replay Board */}
        <div className="board-wrapper replay-board-wrapper">
          <div className={`game-board grid-size-${boardSize}`}>
            {replayBoard.map((val, idx) => (
              <div
                key={idx}
                className={`board-cell ${val ? `filled cell-${val.toLowerCase()}` : 'empty'} ${
                  idx === lastMoveIndex ? 'replay-highlight' : ''
                }`}
              >
                {val === 'X' && (
                  <span
                    className="replay-marker"
                    style={{ color: p1.marker === 'X' ? p1.color : p2.color }}
                  >
                    ✕
                  </span>
                )}
                {val === 'O' && (
                  <span
                    className="replay-marker"
                    style={{ color: p1.marker === 'O' ? p1.color : p2.color }}
                  >
                    ○
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Controls */}
        <div className="replay-controls">
          <button
            type="button"
            className="btn btn-control"
            onClick={() => {
              setIsPlaying(false);
              setStep((s) => Math.max(0, s - 1));
            }}
            disabled={step === 0}
            title="Step Back"
          >
            <ChevronLeft size={18} />
          </button>

          <button
            type="button"
            className="btn btn-primary replay-play-btn"
            onClick={() => {
              if (step >= moves.length) setStep(0);
              setIsPlaying(!isPlaying);
            }}
          >
            {isPlaying ? <Pause size={18} /> : <Play size={18} />}
          </button>

          <button
            type="button"
            className="btn btn-control"
            onClick={() => {
              setIsPlaying(false);
              setStep((s) => Math.min(moves.length, s + 1));
            }}
            disabled={step === moves.length}
            title="Step Forward"
          >
            <ChevronRight size={18} />
          </button>

          <button
            type="button"
            className="btn btn-control"
            onClick={() => {
              setIsPlaying(false);
              setStep(0);
            }}
            title="Restart Replay"
          >
            <RotateCcw size={16} />
          </button>

          <button
            type="button"
            className="btn btn-speed"
            onClick={() => setSpeed((s) => (s === 1 ? 2 : 1))}
          >
            {speed}x
          </button>
        </div>
      </div>
    </div>
  );
};
