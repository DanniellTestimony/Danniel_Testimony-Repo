import React from 'react';
import type { Player, PlayerProfile, PlayerStats } from '../types/game';
import { Flame, MinusSquare } from 'lucide-react';

interface ScoreBoardProps {
  p1: PlayerProfile;
  p2: PlayerProfile;
  seriesScores: { X: number; O: number; draws: number };
  overallStats: { p1: PlayerStats; p2: PlayerStats; ai: PlayerStats };
  currentPlayer: Player;
  gameOver: boolean;
  gameMode: string;
}

export const ScoreBoard: React.FC<ScoreBoardProps> = ({
  p1,
  p2,
  seriesScores,
  overallStats,
  currentPlayer,
  gameOver,
  gameMode,
}) => {
  const p2Stats = gameMode === 'ai' ? overallStats.ai : overallStats.p2;

  return (
    <section className="scoreboard" aria-label="Game Scoreboard">
      {/* Player 1 Card */}
      <div
        className={`score-card player-p1 ${
          !gameOver && currentPlayer === p1.marker ? 'active-turn' : ''
        }`}
        style={{ '--card-accent': p1.color } as React.CSSProperties}
      >
        <div className="score-header">
          <span className="score-avatar">{p1.avatar}</span>
          <span className="score-title">{p1.name}</span>
        </div>
        <div className="score-count" style={{ color: p1.color }}>
          {seriesScores[p1.marker]}
        </div>
        <div className="score-footer">
          {overallStats.p1.currentStreak > 1 && (
            <span className="streak-badge">
              <Flame size={12} /> {overallStats.p1.currentStreak} streak
            </span>
          )}
          <span className="score-label">Rounds Won</span>
        </div>
      </div>

      {/* Ties / Draws Card */}
      <div className="score-card draws">
        <div className="score-header">
          <MinusSquare size={16} className="score-icon" />
          <span className="score-title">Ties</span>
        </div>
        <div className="score-count">{seriesScores.draws}</div>
        <span className="score-label">Draws</span>
      </div>

      {/* Player 2 / AI Card */}
      <div
        className={`score-card player-p2 ${
          !gameOver && currentPlayer === p2.marker ? 'active-turn' : ''
        }`}
        style={{ '--card-accent': p2.color } as React.CSSProperties}
      >
        <div className="score-header">
          <span className="score-avatar">{p2.avatar}</span>
          <span className="score-title">{p2.name}</span>
        </div>
        <div className="score-count" style={{ color: p2.color }}>
          {seriesScores[p2.marker]}
        </div>
        <div className="score-footer">
          {p2Stats.currentStreak > 1 && (
            <span className="streak-badge">
              <Flame size={12} /> {p2Stats.currentStreak} streak
            </span>
          )}
          <span className="score-label">Rounds Won</span>
        </div>
      </div>
    </section>
  );
};
