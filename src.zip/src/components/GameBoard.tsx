import React, { useEffect, useRef } from 'react';
import type { Board, BoardSize, PlayerProfile } from '../types/game';
import { Cell } from './Cell';

interface GameBoardProps {
  board: Board;
  boardSize: BoardSize;
  winningCells: number[];
  winningCoords?: { x1: number; y1: number; x2: number; y2: number };
  hintCell: number | null;
  invalidCell: number | null;
  disabled: boolean;
  p1: PlayerProfile;
  p2: PlayerProfile;
  onCellClick: (index: number) => void;
}

export const GameBoard: React.FC<GameBoardProps> = ({
  board,
  boardSize,
  winningCells,
  winningCoords,
  hintCell,
  invalidCell,
  disabled,
  p1,
  p2,
  onCellClick,
}) => {
  const boardRef = useRef<HTMLDivElement>(null);

  // Keyboard navigation support: Arrow keys, WASD, Enter, Space, Numpad 1-9
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const activeElement = document.activeElement;
      if (!boardRef.current || !boardRef.current.contains(activeElement)) return;

      const currentIndex = Number(activeElement?.getAttribute('data-index') ?? 0);
      let targetIndex = currentIndex;

      if (e.key === 'ArrowRight' || e.key.toLowerCase() === 'd') {
        targetIndex = (currentIndex + 1) % board.length;
      } else if (e.key === 'ArrowLeft' || e.key.toLowerCase() === 'a') {
        targetIndex = (currentIndex - 1 + board.length) % board.length;
      } else if (e.key === 'ArrowDown' || e.key.toLowerCase() === 's') {
        targetIndex = (currentIndex + boardSize) % board.length;
      } else if (e.key === 'ArrowUp' || e.key.toLowerCase() === 'w') {
        targetIndex = (currentIndex - boardSize + board.length) % board.length;
      } else if (boardSize === 3 && /^[1-9]$/.test(e.key)) {
        // Numpad 1-9 mapping for 3x3
        const numMap = [6, 7, 8, 3, 4, 5, 0, 1, 2];
        const mapped = numMap[Number(e.key) - 1];
        if (mapped !== undefined) {
          onCellClick(mapped);
          return;
        }
      }

      if (targetIndex !== currentIndex) {
        e.preventDefault();
        const targetBtn = boardRef.current.querySelector(
          `button[data-index="${targetIndex}"]`
        ) as HTMLButtonElement;
        targetBtn?.focus();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [board.length, boardSize, onCellClick]);

  return (
    <main className="board-wrapper">
      <div
        ref={boardRef}
        className={`game-board grid-size-${boardSize}`}
        role="grid"
        aria-label={`Tic-Tac-Toe ${boardSize} by ${boardSize} Game Board`}
      >
        {board.map((cellValue, index) => (
          <Cell
            key={index}
            index={index}
            value={cellValue}
            isWinningCell={winningCells.includes(index)}
            isHintCell={hintCell === index}
            isInvalid={invalidCell === index}
            disabled={disabled}
            p1={p1}
            p2={p2}
            onClick={onCellClick}
          />
        ))}

        {/* Winning SVG connecting line overlay */}
        {winningCoords && (
          <svg className="winning-line-svg" viewBox="0 0 100 100" aria-hidden="true">
            <line
              x1={winningCoords.x1}
              y1={winningCoords.y1}
              x2={winningCoords.x2}
              y2={winningCoords.y2}
              stroke="var(--primary-blue)"
              strokeWidth="6"
              strokeLinecap="round"
              className="win-line-animated"
            />
          </svg>
        )}
      </div>
    </main>
  );
};
