import React from 'react';
import { RotateCcw, Undo2, Lightbulb, PlaySquare } from 'lucide-react';

interface GameControlsProps {
  canUndo: boolean;
  onUndo: () => void;
  onHint: () => void;
  onRematch: () => void;
  onReplay: () => void;
  hasReplay: boolean;
  gameEnded: boolean;
}

export const GameControls: React.FC<GameControlsProps> = ({
  canUndo,
  onUndo,
  onHint,
  onRematch,
  onReplay,
  hasReplay,
  gameEnded,
}) => {
  return (
    <section className="game-controls" aria-label="Game Interactive Controls">
      {/* Undo Button */}
      <button
        type="button"
        className="btn btn-control"
        onClick={onUndo}
        disabled={!canUndo || gameEnded}
        title="Undo last move (Shortcut: U)"
        aria-label="Undo move"
      >
        <Undo2 size={16} />
        <span>Undo</span>
      </button>

      {/* Hint Button */}
      <button
        type="button"
        className="btn btn-control"
        onClick={onHint}
        disabled={gameEnded}
        title="Suggest optimal next move (Shortcut: H)"
        aria-label="Hint next move"
      >
        <Lightbulb size={16} />
        <span>Hint</span>
      </button>

      {/* Rematch Button */}
      <button
        type="button"
        className="btn btn-primary btn-rematch"
        onClick={onRematch}
        title="Play next round (Shortcut: R)"
        aria-label="Play next round"
      >
        <RotateCcw size={16} />
        <span>{gameEnded ? 'Next Round' : 'Restart'}</span>
      </button>

      {/* Replay Button */}
      {hasReplay && (
        <button
          type="button"
          className="btn btn-control btn-replay"
          onClick={onReplay}
          title="Watch move-by-move replay"
          aria-label="Replay match"
        >
          <PlaySquare size={16} />
          <span>Replay</span>
        </button>
      )}
    </section>
  );
};
