import React from 'react';
import {
  Sun,
  Moon,
  Volume2,
  VolumeX,
  Settings,
  BarChart2,
  HelpCircle,
  Sparkles,
  ArrowLeft,
} from 'lucide-react';
import type { GameSettings } from '../types/game';

interface HeaderProps {
  inGame: boolean;
  settings: GameSettings;
  onUpdateSettings: (settings: Partial<GameSettings>) => void;
  onOpenSettings: () => void;
  onOpenStats: () => void;
  onOpenHowToPlay: () => void;
  onBackToLobby: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  inGame,
  settings,
  onUpdateSettings,
  onOpenSettings,
  onOpenStats,
  onOpenHowToPlay,
  onBackToLobby,
}) => {
  return (
    <header className="app-header">
      <div className="header-top-row">
        <div className="header-brand-group">
          {inGame && (
            <button
              type="button"
              className="lobby-back-btn"
              onClick={onBackToLobby}
              title="Return to Main Menu"
              aria-label="Back to Setup Lobby"
            >
              <ArrowLeft size={18} />
            </button>
          )}

          <div className="brand-logo-badge">
            <div className="logo-sparkle-box">
              <Sparkles size={18} className="logo-sparkle-icon" />
            </div>
            <div className="brand-meta">
              <span className="brand-title">OLAYODE DANIEL</span>
              <span className="brand-edition">Blue Pro Edition</span>
            </div>
          </div>
        </div>

        <nav className="header-actions" aria-label="Game Quick Settings">
          <button
            type="button"
            className="icon-btn theme-toggle"
            onClick={() => onUpdateSettings({ darkMode: !settings.darkMode })}
            title={settings.darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            aria-label="Toggle Dark Mode"
          >
            {settings.darkMode ? <Sun size={18} /> : <Moon size={18} />}
          </button>

          <button
            type="button"
            className="icon-btn sound-toggle"
            onClick={() => onUpdateSettings({ soundEnabled: !settings.soundEnabled })}
            title={settings.soundEnabled ? 'Mute Sounds' : 'Enable Sounds'}
            aria-label="Toggle Sound Effects"
          >
            {settings.soundEnabled ? <Volume2 size={18} /> : <VolumeX size={18} />}
          </button>

          <button
            type="button"
            className="icon-btn stats-trigger"
            onClick={onOpenStats}
            title="Statistics & Leaderboard"
            aria-label="View Statistics and Match History"
          >
            <BarChart2 size={18} />
          </button>

          <button
            type="button"
            className="icon-btn help-trigger"
            onClick={onOpenHowToPlay}
            title="How to Play & Shortcuts"
            aria-label="How to Play"
          >
            <HelpCircle size={18} />
          </button>

          <button
            type="button"
            className="icon-btn settings-trigger"
            onClick={onOpenSettings}
            title="Game Settings"
            aria-label="Open Settings"
          >
            <Settings size={18} />
          </button>
        </nav>
      </div>

      <p className="brand-tagline">Classic game. Clean design. Blue by Daniel.</p>
    </header>
  );
};
