import React from 'react';
import { Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="app-footer">
      <p>
        Designed &amp; Built for <strong>Olayode Daniel</strong>
      </p>
      <div className="footer-credits">
        <span>Blue Brand Experience</span>
        <span className="dot-sep">•</span>
        <span className="made-with">
          Crafted with <Heart size={14} className="heart-icon" /> in React + Vite
        </span>
      </div>
    </footer>
  );
};
