import React, { useState } from 'react';
import type { GameSettings, ThemeId, TimerDuration } from '../types/game';
import { X, Moon, Sun, Volume2, VolumeX, Palette, Clock, Trash2 } from 'lucide-react';
import { ConfirmModal } from './ConfirmModal';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: GameSettings;
  onUpdateSettings: (settings: Partial<GameSettings>) => void;
  onResetAllData: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  onResetAllData,
}) => {
  const [showConfirmReset, setShowConfirmReset] = useState(false);

  if (!isOpen) return null;

  const themes: { id: ThemeId; label: string; preview: string }[] = [
    { id: 'classic-blue', label: 'Classic Blue', preview: '#2563eb' },
    { id: 'neon-cyberpunk', label: 'Neon Cyberpunk', preview: '#00f2fe' },
    { id: 'dark-minimal', label: 'Dark Minimal', preview: '#38bdf8' },
    { id: 'emerald-forest', label: 'Emerald Forest', preview: '#059669' },
    { id: 'sunset-glow', label: 'Sunset Glow', preview: '#f59e0b' },
  ];

  return (
    <>
      <div className="modal-backdrop" onClick={onClose}>
        <div className="modal-content settings-modal" onClick={(e) => e.stopPropagation()}>
          <div className="modal-header">
            <h3 className="modal-title">⚙️ Game Settings</h3>
            <button type="button" className="modal-close-btn" onClick={onClose} aria-label="Close">
              <X size={18} />
            </button>
          </div>

          <div className="settings-body">
            {/* Dark Mode */}
            <div className="setting-row">
              <div className="setting-info">
                <span className="setting-label">Dark Appearance</span>
                <span className="setting-desc">Toggle dark background & high contrast</span>
              </div>
              <button
                type="button"
                className={`switch-btn ${settings.darkMode ? 'active' : ''}`}
                onClick={() => onUpdateSettings({ darkMode: !settings.darkMode })}
              >
                {settings.darkMode ? <Moon size={16} /> : <Sun size={16} />}
              </button>
            </div>

            {/* Custom Themes */}
            <div className="setting-section">
              <label className="setting-section-label">
                <Palette size={16} /> Theme Palette
              </label>
              <div className="theme-options-grid">
                {themes.map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    className={`theme-chip ${settings.theme === t.id ? 'selected' : ''}`}
                    onClick={() => onUpdateSettings({ theme: t.id })}
                  >
                    <span className="theme-color-blob" style={{ backgroundColor: t.preview }} />
                    <span className="theme-name">{t.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Sound FX */}
            <div className="setting-row">
              <div className="setting-info">
                <span className="setting-label">Sound Effects</span>
                <span className="setting-desc">Real-time Web Audio synthesizer</span>
              </div>
              <button
                type="button"
                className={`switch-btn ${settings.soundEnabled ? 'active' : ''}`}
                onClick={() => onUpdateSettings({ soundEnabled: !settings.soundEnabled })}
              >
                {settings.soundEnabled ? <Volume2 size={16} /> : <VolumeX size={16} />}
              </button>
            </div>

            {/* Turn Timer Default */}
            <div className="setting-section">
              <label className="setting-section-label">
                <Clock size={16} /> Default Move Timer
              </label>
              <div className="pill-selector four-col">
                {[
                  { label: 'Off', val: 0 },
                  { label: '5s', val: 5 },
                  { label: '10s', val: 10 },
                  { label: '15s', val: 15 },
                ].map((t) => (
                  <button
                    key={t.val}
                    type="button"
                    className={`pill-btn ${settings.timerDuration === t.val ? 'active' : ''}`}
                    onClick={() => onUpdateSettings({ timerDuration: t.val as TimerDuration })}
                  >
                    {t.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Danger Zone */}
            <div className="danger-zone">
              <span className="danger-title">Danger Zone</span>
              <button
                type="button"
                className="btn btn-danger"
                onClick={() => setShowConfirmReset(true)}
              >
                <Trash2 size={16} />
                <span>Wipe Statistics & History</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      <ConfirmModal
        isOpen={showConfirmReset}
        title="Clear All Statistics?"
        message="Are you sure you want to permanently wipe all stored win/loss records, match histories, and device leaderboard data?"
        confirmLabel="Yes, Wipe All"
        onConfirm={() => {
          setShowConfirmReset(false);
          onResetAllData();
        }}
        onCancel={() => setShowConfirmReset(false)}
      />
    </>
  );
};
