import React from 'react';
import type { CellValue, PlayerProfile } from '../types/game';

interface CellProps {
  index: number;
  value: CellValue;
  isWinningCell: boolean;
  isHintCell: boolean;
  isInvalid: boolean;
  disabled: boolean;
  p1: PlayerProfile;
  p2: PlayerProfile;
  onClick: (index: number) => void;
}

export const Cell: React.FC<CellProps> = ({
  index,
  value,
  isWinningCell,
  isHintCell,
  isInvalid,
  disabled,
  p1,
  p2,
  onClick,
}) => {
  const getMarkerColor = () => {
    if (!value) return 'currentColor';
    return value === p1.marker ? p1.color : p2.color;
  };

  const getAriaLabel = () => {
    if (value) {
      const pName = value === p1.marker ? p1.name : p2.name;
      return `Cell ${index + 1}: ${pName} (${value})${isWinningCell ? ', winning position' : ''}`;
    }
    return `Cell ${index + 1}, empty`;
  };

  return (
    <button
      type="button"
      className={`board-cell ${value ? `filled cell-${value.toLowerCase()}` : 'empty'} ${
        isWinningCell ? 'winning-cell' : ''
      } ${isHintCell ? 'hint-pulse' : ''} ${isInvalid ? 'invalid-shake' : ''}`}
      onClick={() => onClick(index)}
      disabled={disabled || value !== null}
      aria-label={getAriaLabel()}
      tabIndex={0}
      data-index={index}
    >
      {value === 'X' && (
        <svg
          viewBox="0 0 100 100"
          className="marker-svg marker-x"
          style={{ color: getMarkerColor() }}
          aria-hidden="true"
        >
          <line
            x1="22"
            y1="22"
            x2="78"
            y2="78"
            stroke="currentColor"
            strokeWidth="14"
            strokeLinecap="round"
            className="x-stroke-1"
          />
          <line
            x1="78"
            y1="22"
            x2="22"
            y2="78"
            stroke="currentColor"
            strokeWidth="14"
            strokeLinecap="round"
            className="x-stroke-2"
          />
        </svg>
      )}

      {value === 'O' && (
        <svg
          viewBox="0 0 100 100"
          className="marker-svg marker-o"
          style={{ color: getMarkerColor() }}
          aria-hidden="true"
        >
          <circle
            cx="50"
            cy="50"
            r="32"
            fill="none"
            stroke="currentColor"
            strokeWidth="14"
            strokeLinecap="round"
            className="o-stroke"
          />
        </svg>
      )}

      {isHintCell && !value && (
        <span className="hint-indicator-dot" />
      )}
    </button>
  );
};
