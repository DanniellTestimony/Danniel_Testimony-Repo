import React from 'react';
import { X, Keyboard, Target, Sparkles } from 'lucide-react';

interface HowToPlayModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HowToPlayModal: React.FC<HowToPlayModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-content help-modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h3 className="modal-title">📖 How to Play &amp; Controls</h3>
          <button type="button" className="modal-close-btn" onClick={onClose} aria-label="Close">
            <X size={18} />
          </button>
        </div>

        <div className="help-body">
          <div className="help-section">
            <h4 className="help-subhead">
              <Target size={16} /> Objective &amp; Grid Sizes
            </h4>
            <ul className="help-list">
              <li>
                <strong>3×3 Grid</strong>: Connect <strong>3 markers in a row</strong> (horizontal, vertical, or diagonal).
              </li>
              <li>
                <strong>4×4 Grid</strong>: Connect <strong>4 markers in a row</strong>.
              </li>
              <li>
                <strong>5×5 Grid</strong>: Connect <strong>4 markers in a row</strong> (dynamic Gomoku standard).
              </li>
            </ul>
          </div>

          <div className="help-section">
            <h4 className="help-subhead">
              <Keyboard size={16} /> Keyboard Controls
            </h4>
            <div className="shortcuts-grid">
              <div className="shortcut-row">
                <kbd className="key-badge">Arrow Keys / WASD</kbd>
                <span>Navigate grid cells</span>
              </div>
              <div className="shortcut-row">
                <kbd className="key-badge">Space / Enter</kbd>
                <span>Place marker in active cell</span>
              </div>
              <div className="shortcut-row">
                <kbd className="key-badge">1 - 9 (Numpad)</kbd>
                <span>Direct move selection on 3×3</span>
              </div>
              <div className="shortcut-row">
                <kbd className="key-badge">U</kbd>
                <span>Undo previous move</span>
              </div>
              <div className="shortcut-row">
                <kbd className="key-badge">H</kbd>
                <span>Ask AI for a strategic Hint</span>
              </div>
              <div className="shortcut-row">
                <kbd className="key-badge">R</kbd>
                <span>Rematch / Start next round</span>
              </div>
            </div>
          </div>

          <div className="help-section">
            <h4 className="help-subhead">
              <Sparkles size={16} /> Pro Tips
            </h4>
            <p className="help-tip">
              Control the center square and corner positions early to create fork threats that your opponent cannot block simultaneously!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
