import React, { useState } from 'react';
import type { GameHistoryItem, LeaderboardEntry, PlayerStats } from '../types/game';
import { X, BarChart2, History, Award, Flame } from 'lucide-react';

interface StatsModalProps {
  isOpen: boolean;
  onClose: () => void;
  overallStats: { p1: PlayerStats; p2: PlayerStats; ai: PlayerStats };
  history: GameHistoryItem[];
  leaderboard: LeaderboardEntry[];
}

export const StatsModal: React.FC<StatsModalProps> = ({
  isOpen,
  onClose,
  overallStats,
  history,
  leaderboard,
}) => {
  const [tab, setTab] = useState<'overview' | 'history' | 'leaderboard'>('overview');

  if (!isOpen) return null;

  const totalP1Games = overallStats.p1.wins + overallStats.p1.losses + overallStats.p1.draws;
  const p1WinRate = totalP1Games > 0 ? Math.round((overallStats.p1.wins / totalP1Games) * 100) : 0;

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-content stats-modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h3 className="modal-title">📊 Analytics & Leaderboard</h3>
          <button type="button" className="modal-close-btn" onClick={onClose} aria-label="Close">
            <X size={18} />
          </button>
        </div>

        <div className="modal-tabs">
          <button
            type="button"
            className={`tab-btn ${tab === 'overview' ? 'active' : ''}`}
            onClick={() => setTab('overview')}
          >
            <BarChart2 size={16} />
            <span>Overview</span>
          </button>
          <button
            type="button"
            className={`tab-btn ${tab === 'history' ? 'active' : ''}`}
            onClick={() => setTab('history')}
          >
            <History size={16} />
            <span>History ({history.length})</span>
          </button>
          <button
            type="button"
            className={`tab-btn ${tab === 'leaderboard' ? 'active' : ''}`}
            onClick={() => setTab('leaderboard')}
          >
            <Award size={16} />
            <span>Leaderboard</span>
          </button>
        </div>

        <div className="stats-tab-content">
          {tab === 'overview' && (
            <div className="overview-container">
              <div className="stats-metric-cards">
                <div className="metric-box">
                  <span className="metric-num">{overallStats.p1.wins}</span>
                  <span className="metric-label">P1 Wins</span>
                </div>
                <div className="metric-box">
                  <span className="metric-num">{p1WinRate}%</span>
                  <span className="metric-label">Win Rate</span>
                </div>
                <div className="metric-box">
                  <span className="metric-num streak-num">
                    <Flame size={16} /> {overallStats.p1.bestStreak}
                  </span>
                  <span className="metric-label">Best Streak</span>
                </div>
                <div className="metric-box">
                  <span className="metric-num">{totalP1Games}</span>
                  <span className="metric-label">Total Matches</span>
                </div>
              </div>

              <div className="stats-breakdown-card">
                <h4 className="card-subhead">Player 1 Record</h4>
                <div className="record-bar-container">
                  <div className="record-labels">
                    <span className="rec-win">Wins: {overallStats.p1.wins}</span>
                    <span className="rec-draw">Ties: {overallStats.p1.draws}</span>
                    <span className="rec-loss">Losses: {overallStats.p1.losses}</span>
                  </div>
                </div>
              </div>

              <div className="stats-breakdown-card">
                <h4 className="card-subhead">AI Engine Record</h4>
                <div className="record-labels">
                  <span className="rec-win">AI Wins: {overallStats.ai.wins}</span>
                  <span className="rec-draw">Draws: {overallStats.ai.draws}</span>
                  <span className="rec-loss">AI Defeats: {overallStats.ai.losses}</span>
                </div>
              </div>
            </div>
          )}

          {tab === 'history' && (
            <div className="history-list-container">
              {history.length === 0 ? (
                <div className="empty-history">No matches recorded yet. Play a game!</div>
              ) : (
                history.map((item) => (
                  <div key={item.id} className="history-item">
                    <div className="history-main">
                      <span className="history-winner">
                        {item.winner === 'draw' ? '🤝 Draw' : `🏆 ${item.winnerName}`}
                      </span>
                      <span className="history-details">
                        {item.boardSize}×{item.boardSize} Grid • {item.movesCount} moves • {item.durationSeconds}s
                      </span>
                    </div>
                    <span className="history-date">{item.date}</span>
                  </div>
                ))
              )}
            </div>
          )}

          {tab === 'leaderboard' && (
            <div className="leaderboard-container">
              <div className="leaderboard-table">
                <div className="lb-header">
                  <span>Rank & Player</span>
                  <span>Wins</span>
                  <span>Matches</span>
                  <span>Win Rate</span>
                </div>
                {leaderboard.map((entry, idx) => (
                  <div key={idx} className={`lb-row ${idx === 0 ? 'top-rank' : ''}`}>
                    <div className="lb-player-cell">
                      <span className="lb-rank">#{idx + 1}</span>
                      <span className="lb-avatar">{entry.avatar}</span>
                      <span className="lb-name">{entry.name}</span>
                    </div>
                    <span className="lb-val">{entry.wins}</span>
                    <span className="lb-val">{entry.matches}</span>
                    <span className="lb-val lb-rate">{entry.winRate}%</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
