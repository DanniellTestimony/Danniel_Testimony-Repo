import React from 'react';
import type { Player, PlayerProfile, MatchSeries } from '../types/game';
import { Trophy, AlertCircle, Clock, Loader2 } from 'lucide-react';

interface GameStatusProps {
  currentPlayer: Player;
  winner: Player | null;
  isDraw: boolean;
  isAiThinking: boolean;
  p1: PlayerProfile;
  p2: PlayerProfile;
  timeLeft: number;
  timerDuration: number;
  matchSeries: MatchSeries;
  seriesScores: { X: number; O: number; draws: number };
}

export const GameStatus: React.FC<GameStatusProps> = ({
  currentPlayer,
  winner,
  isDraw,
  isAiThinking,
  p1,
  p2,
  timeLeft,
  timerDuration,
  matchSeries,
  seriesScores,
}) => {
  const activeProfile = currentPlayer === p1.marker ? p1 : p2;
  const winnerProfile = winner ? (winner === p1.marker ? p1 : p2) : null;

  return (
    <section className="game-status-wrapper" aria-label="Game Turn & Series Status">
      {/* Series Match Dots Tracker */}
      {matchSeries > 1 && (
        <div className="series-tracker">
          <div className="series-player-dots">
            <span className="series-p-name">{p1.name}</span>
            <div className="dots-row">
              {Array.from({ length: Math.ceil(matchSeries / 2) }).map((_, i) => (
                <span
                  key={i}
                  className={`series-dot ${i < seriesScores[p1.marker] ? 'filled' : ''}`}
                  style={{ backgroundColor: i < seriesScores[p1.marker] ? p1.color : undefined }}
                />
              ))}
            </div>
          </div>

          <div className="series-badge">Best of {matchSeries}</div>

          <div className="series-player-dots">
            <span className="series-p-name">{p2.name}</span>
            <div className="dots-row">
              {Array.from({ length: Math.ceil(matchSeries / 2) }).map((_, i) => (
                <span
                  key={i}
                  className={`series-dot ${i < seriesScores[p2.marker] ? 'filled' : ''}`}
                  style={{ backgroundColor: i < seriesScores[p2.marker] ? p2.color : undefined }}
                />
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Main Status Banner */}
      {winner && winnerProfile ? (
        <div className="game-status status-winner" role="status" aria-live="polite">
          <Trophy className="status-icon winner-icon" size={24} />
          <div className="status-text">
            <span className="winner-highlight">
              {winnerProfile.avatar} {winnerProfile.name} Wins!
            </span>
            <span className="status-sub">Outstanding tactical match!</span>
          </div>
        </div>
      ) : isDraw ? (
        <div className="game-status status-draw" role="status" aria-live="polite">
          <AlertCircle className="status-icon draw-icon" size={24} />
          <div className="status-text">
            <span>Game Ended in a Draw!</span>
            <span className="status-sub">Both players defended masterfully.</span>
          </div>
        </div>
      ) : (
        <div className="game-status status-turn" role="status" aria-live="polite">
          <div className="turn-avatar-badge" style={{ borderColor: activeProfile.color }}>
            <span>{activeProfile.avatar}</span>
          </div>

          <div className="status-text">
            <div className="turn-title-row">
              <span>Turn:</span>
              <strong className="active-player-name" style={{ color: activeProfile.color }}>
                {activeProfile.name} ({activeProfile.marker})
              </strong>
              {isAiThinking && (
                <span className="ai-thinking-indicator">
                  <Loader2 size={14} className="spin-icon" />
                  Thinking...
                </span>
              )}
            </div>
          </div>

          {/* Move Timer Bar / Counter */}
          {timerDuration > 0 && (
            <div className={`turn-timer-chip ${timeLeft <= 3 ? 'danger-pulse' : ''}`}>
              <Clock size={14} />
              <span>{timeLeft}s</span>
            </div>
          )}
        </div>
      )}
    </section>
  );
};
