import React from 'react';
import type { Board, BoardSize, Player, PlayerProfile } from '../types/game';
import { generateShareResultText } from '../utils/share';
import { Trophy, Share2, PlaySquare, RotateCcw, X, Clock, Zap } from 'lucide-react';

interface MatchSummaryModalProps {
  isOpen: boolean;
  onClose: () => void;
  winner: Player | 'draw';
  p1: PlayerProfile;
  p2: PlayerProfile;
  board: Board;
  boardSize: BoardSize;
  movesCount: number;
  durationSeconds: number;
  onRematch: () => void;
  onWatchReplay: () => void;
  onShowToast: (msg: string) => void;
}

export const MatchSummaryModal: React.FC<MatchSummaryModalProps> = ({
  isOpen,
  onClose,
  winner,
  p1,
  p2,
  board,
  boardSize,
  movesCount,
  durationSeconds,
  onRematch,
  onWatchReplay,
  onShowToast,
}) => {
  if (!isOpen) return null;

  const winnerProfile = winner !== 'draw' ? (winner === p1.marker ? p1 : p2) : null;

  const handleShare = async () => {
    const text = generateShareResultText(
      board,
      boardSize,
      winner,
      p1,
      p2,
      movesCount,
      durationSeconds
    );
    try {
      await navigator.clipboard.writeText(text);
      onShowToast('📋 Match result card copied to clipboard!');
    } catch {
      onShowToast('Failed to copy to clipboard');
    }
  };

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-content summary-modal" onClick={(e) => e.stopPropagation()}>
        <button type="button" className="modal-close-btn" onClick={onClose} aria-label="Close">
          <X size={18} />
        </button>

        <div className="summary-header">
          {winner !== 'draw' && winnerProfile ? (
            <>
              <div className="trophy-wrapper">
                <Trophy size={48} className="trophy-gold" />
              </div>
              <h2 className="summary-title">{winnerProfile.name} Triumphs!</h2>
              <p className="summary-subtitle">
                Victory achieved with marker <strong>{winnerProfile.marker}</strong>
              </p>
            </>
          ) : (
            <>
              <div className="draw-icon-large">🤝</div>
              <h2 className="summary-title">Epic Draw!</h2>
              <p className="summary-subtitle">Evenly matched battle of wits</p>
            </>
          )}
        </div>

        {/* Metrics */}
        <div className="summary-stats-grid">
          <div className="stat-card">
            <Zap size={18} className="stat-icon" />
            <span className="stat-value">{movesCount}</span>
            <span className="stat-label">Total Moves</span>
          </div>

          <div className="stat-card">
            <Clock size={18} className="stat-icon" />
            <span className="stat-value">{durationSeconds}s</span>
            <span className="stat-label">Duration</span>
          </div>
        </div>

        {/* Actions */}
        <div className="summary-actions">
          <button
            type="button"
            className="btn btn-primary"
            onClick={() => {
              onClose();
              onRematch();
            }}
          >
            <RotateCcw size={18} />
            <span>Play Next Round</span>
          </button>

          <button
            type="button"
            className="btn btn-secondary"
            onClick={() => {
              onClose();
              onWatchReplay();
            }}
          >
            <PlaySquare size={18} />
            <span>Watch Replay</span>
          </button>

          <button type="button" className="btn btn-share" onClick={handleShare}>
            <Share2 size={18} />
            <span>Share Result</span>
          </button>
        </div>
      </div>
    </div>
  );
};
