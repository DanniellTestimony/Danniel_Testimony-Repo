import React from 'react';

interface ToastProps {
  message: string | null;
}

export const Toast: React.FC<ToastProps> = ({ message }) => {
  if (!message) return null;

  return (
    <div className="toast-container" role="alert" aria-live="assertive">
      <div className="toast-content">{message}</div>
    </div>
  );
};
