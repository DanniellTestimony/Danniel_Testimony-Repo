import React, { useState } from 'react';
import type {
  BoardSize,
  GameMode,
  AIDifficulty,
  MatchSeries,
  PlayerProfile,
  TimerDuration,
} from '../types/game';
import { AVATAR_OPTIONS, COLOR_OPTIONS } from '../hooks/useGame';
import { Play, Users, Bot, Grid3X3, Clock, Trophy, Sparkles, BarChart2, HelpCircle } from 'lucide-react';

interface StartScreenProps {
  onStart: (
    mode: GameMode,
    size: BoardSize,
    series: MatchSeries,
    diff: AIDifficulty,
    p1: PlayerProfile,
    p2: PlayerProfile,
    timer: TimerDuration
  ) => void;
  onOpenStats: () => void;
  onOpenHowToPlay: () => void;
}

export const StartScreen: React.FC<StartScreenProps> = ({
  onStart,
  onOpenStats,
  onOpenHowToPlay,
}) => {
  const [mode, setMode] = useState<GameMode>('pvp');
  const [boardSize, setBoardSize] = useState<BoardSize>(3);
  const [series, setSeries] = useState<MatchSeries>(1);
  const [difficulty, setDifficulty] = useState<AIDifficulty>('hard');
  const [timer, setTimer] = useState<TimerDuration>(0);

  const [p1Name, setP1Name] = useState('Player 1');
  const [p1Marker, setP1Marker] = useState<'X' | 'O'>('X');
  const [p1Avatar, setP1Avatar] = useState('👑');
  const [p1Color, setP1Color] = useState('#2563EB');

  const [p2Name, setP2Name] = useState('Player 2');
  const [p2Avatar, setP2Avatar] = useState('⚡');
  const [p2Color, setP2Color] = useState('#0284C7');

  const p2Marker = p1Marker === 'X' ? 'O' : 'X';

  const handleStart = () => {
    const finalP1: PlayerProfile = {
      name: p1Name.trim() || 'Player 1',
      marker: p1Marker,
      avatar: p1Avatar,
      color: p1Color,
    };

    const finalP2: PlayerProfile = {
      name: mode === 'ai' ? `AI Bot (${difficulty.toUpperCase()})` : p2Name.trim() || 'Player 2',
      marker: p2Marker,
      avatar: mode === 'ai' ? '🤖' : p2Avatar,
      color: p2Color,
    };

    onStart(mode, boardSize, series, difficulty, finalP1, finalP2, timer);
  };

  return (
    <div className="start-screen-container">
      <div className="lobby-hero">
        <div className="hero-badge">
          <Sparkles size={16} />
          <span>Olayode Daniel Premium Gaming</span>
        </div>
        <h1 className="lobby-title">Tic-Tac-Toe Arena</h1>
        <p className="lobby-desc">Select your mode, customize players, and compete for victory.</p>
      </div>

      <div className="lobby-card-grid">
        <div className="setup-section">
          <label className="section-title">
            <Users size={16} /> Game Mode
          </label>
          <div className="pill-selector">
            <button
              type="button"
              className={`pill-btn ${mode === 'pvp' ? 'active' : ''}`}
              onClick={() => setMode('pvp')}
            >
              <Users size={16} />
              <span>2 Players (Local)</span>
            </button>
            <button
              type="button"
              className={`pill-btn ${mode === 'ai' ? 'active' : ''}`}
              onClick={() => setMode('ai')}
            >
              <Bot size={16} />
              <span>Player vs AI</span>
            </button>
          </div>
        </div>

        {mode === 'ai' && (
          <div className="setup-section">
            <label className="section-title">
              <Bot size={16} /> AI Difficulty
            </label>
            <div className="pill-selector three-col">
              {(['easy', 'medium', 'hard'] as AIDifficulty[]).map((d) => (
                <button
                  key={d}
                  type="button"
                  className={`pill-btn ${difficulty === d ? 'active' : ''}`}
                  onClick={() => setDifficulty(d)}
                >
                  {d.toUpperCase()}
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="setup-section">
          <label className="section-title">
            <Grid3X3 size={16} /> Board Grid Size
          </label>
          <div className="pill-selector three-col">
            <button
              type="button"
              className={`pill-btn ${boardSize === 3 ? 'active' : ''}`}
              onClick={() => setBoardSize(3)}
            >
              3×3 (3 to win)
            </button>
            <button
              type="button"
              className={`pill-btn ${boardSize === 4 ? 'active' : ''}`}
              onClick={() => setBoardSize(4)}
            >
              4×4 (4 to win)
            </button>
            <button
              type="button"
              className={`pill-btn ${boardSize === 5 ? 'active' : ''}`}
              onClick={() => setBoardSize(5)}
            >
              5×5 (4 to win)
            </button>
          </div>
        </div>

        <div className="setup-section">
          <label className="section-title">
            <Trophy size={16} /> Match Series
          </label>
          <div className="pill-selector three-col">
            <button
              type="button"
              className={`pill-btn ${series === 1 ? 'active' : ''}`}
              onClick={() => setSeries(1)}
            >
              Single Round
            </button>
            <button
              type="button"
              className={`pill-btn ${series === 3 ? 'active' : ''}`}
              onClick={() => setSeries(3)}
            >
              Best of 3
            </button>
            <button
              type="button"
              className={`pill-btn ${series === 5 ? 'active' : ''}`}
              onClick={() => setSeries(5)}
            >
              Best of 5
            </button>
          </div>
        </div>

        <div className="setup-section">
          <label className="section-title">
            <Clock size={16} /> Turn Timer
          </label>
          <div className="pill-selector four-col">
            {[
              { label: 'Off', val: 0 },
              { label: '5s', val: 5 },
              { label: '10s', val: 10 },
              { label: '15s', val: 15 },
            ].map((t) => (
              <button
                key={t.val}
                type="button"
                className={`pill-btn ${timer === t.val ? 'active' : ''}`}
                onClick={() => setTimer(t.val as TimerDuration)}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>

        <div className="player-custom-container">
          <div className="player-setup-card">
            <div className="player-card-header">
              <span className="player-card-badge">Player 1</span>
              <div className="marker-pick">
                <button
                  type="button"
                  className={`marker-choice ${p1Marker === 'X' ? 'active' : ''}`}
                  onClick={() => setP1Marker('X')}
                >
                  X
                </button>
                <button
                  type="button"
                  className={`marker-choice ${p1Marker === 'O' ? 'active' : ''}`}
                  onClick={() => setP1Marker('O')}
                >
                  O
                </button>
              </div>
            </div>

            <input
              type="text"
              className="player-name-input"
              value={p1Name}
              onChange={(e) => setP1Name(e.target.value)}
              placeholder="Player 1 Name"
              maxLength={14}
            />

            <div className="avatar-palette">
              <span className="sub-label">Avatar:</span>
              <div className="avatar-grid">
                {AVATAR_OPTIONS.slice(0, 5).map((av) => (
                  <button
                    key={av}
                    type="button"
                    className={`avatar-btn ${p1Avatar === av ? 'selected' : ''}`}
                    onClick={() => setP1Avatar(av)}
                  >
                    {av}
                  </button>
                ))}
              </div>
            </div>

            <div className="color-palette">
              <span className="sub-label">Color:</span>
              <div className="color-dots">
                {COLOR_OPTIONS.slice(0, 4).map((c) => (
                  <button
                    key={c}
                    type="button"
                    className={`color-dot ${p1Color === c ? 'selected' : ''}`}
                    style={{ backgroundColor: c }}
                    onClick={() => setP1Color(c)}
                    aria-label={`Select color ${c}`}
                  />
                ))}
              </div>
            </div>
          </div>

          <div className="player-setup-card">
            <div className="player-card-header">
              <span className="player-card-badge">
                {mode === 'ai' ? 'Computer (AI)' : 'Player 2'}
              </span>
              <span className="auto-marker">Marker: {p2Marker}</span>
            </div>

            {mode === 'pvp' ? (
              <>
                <input
                  type="text"
                  className="player-name-input"
                  value={p2Name}
                  onChange={(e) => setP2Name(e.target.value)}
                  placeholder="Player 2 Name"
                  maxLength={14}
                />

                <div className="avatar-palette">
                  <span className="sub-label">Avatar:</span>
                  <div className="avatar-grid">
                    {AVATAR_OPTIONS.slice(5, 10).map((av) => (
                      <button
                        key={av}
                        type="button"
                        className={`avatar-btn ${p2Avatar === av ? 'selected' : ''}`}
                        onClick={() => setP2Avatar(av)}
                      >
                        {av}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="color-palette">
                  <span className="sub-label">Color:</span>
                  <div className="color-dots">
                    {COLOR_OPTIONS.slice(4, 8).map((c) => (
                      <button
                        key={c}
                        type="button"
                        className={`color-dot ${p2Color === c ? 'selected' : ''}`}
                        style={{ backgroundColor: c }}
                        onClick={() => setP2Color(c)}
                        aria-label={`Select color ${c}`}
                      />
                    ))}
                  </div>
                </div>
              </>
            ) : (
              <div className="ai-preview-box">
                <span className="ai-big-avatar">🤖</span>
                <span className="ai-preview-title">AI Engine</span>
                <span className="ai-difficulty-badge">{difficulty.toUpperCase()} MODE</span>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="lobby-actions">
        <button type="button" className="btn btn-primary start-match-btn" onClick={handleStart}>
          <Play size={20} />
          <span>Launch Match</span>
        </button>

        <div className="lobby-quick-links">
          <button type="button" className="lobby-link-btn" onClick={onOpenStats}>
            <BarChart2 size={16} />
            <span>Leaderboard & Stats</span>
          </button>
          <button type="button" className="lobby-link-btn" onClick={onOpenHowToPlay}>
            <HelpCircle size={16} />
            <span>Rules & Controls</span>
          </button>
        </div>
      </div>
    </div>
  );
};
