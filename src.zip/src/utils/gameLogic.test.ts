import { describe, it, expect } from 'vitest';
import {
  checkWinner,
  checkDraw,
  createInitialBoard,
  generateWinningCombinations,
} from './gameLogic';
import { getBestAIMove, getHintMove } from './ai';
import type { Board } from '../types/game';

describe('Tic-Tac-Toe Game Engine & Multi-Size Logic', () => {
  describe('Board Initialization', () => {
    it('creates 3x3 board of 9 cells', () => {
      const board = createInitialBoard(3);
      expect(board).toHaveLength(9);
      expect(board.every((c) => c === null)).toBe(true);
    });

    it('creates 4x4 board of 16 cells', () => {
      const board = createInitialBoard(4);
      expect(board).toHaveLength(16);
    });

    it('creates 5x5 board of 25 cells', () => {
      const board = createInitialBoard(5);
      expect(board).toHaveLength(25);
    });
  });

  describe('Winning Combinations Generation', () => {
    it('generates 8 combos for 3x3 (3 in a row)', () => {
      const combos = generateWinningCombinations(3);
      expect(combos).toHaveLength(8);
    });

    it('generates correct lines for 4x4', () => {
      const combos = generateWinningCombinations(4);
      expect(combos.length).toBeGreaterThan(8);
    });
  });

  describe('3x3 Win Detection', () => {
    it('detects row 0 win for X', () => {
      const board: Board = ['X', 'X', 'X', null, 'O', null, 'O', null, null];
      const res = checkWinner(board, 3);
      expect(res.winner).toBe('X');
      expect(res.winningCells).toEqual([0, 1, 2]);
    });

    it('detects main diagonal win for O', () => {
      const board: Board = ['O', 'X', 'X', null, 'O', null, 'X', null, 'O'];
      const res = checkWinner(board, 3);
      expect(res.winner).toBe('O');
      expect(res.winningCells).toEqual([0, 4, 8]);
    });
  });

  describe('4x4 Win Detection', () => {
    it('detects 4-in-a-row column win for X', () => {
      const board: Board = Array(16).fill(null);
      board[1] = 'X';
      board[5] = 'X';
      board[9] = 'X';
      board[13] = 'X';
      const res = checkWinner(board, 4);
      expect(res.winner).toBe('X');
      expect(res.winningCells).toEqual([1, 5, 9, 13]);
    });
  });

  describe('Draw Detection', () => {
    it('detects draw when full and no winner', () => {
      const board: Board = [
        'X', 'O', 'X',
        'X', 'O', 'O',
        'O', 'X', 'X',
      ];
      expect(checkDraw(board, null)).toBe(true);
    });

    it('is not draw if empty cells remain', () => {
      const board: Board = [
        'X', 'O', 'X',
        'X', null, 'O',
        'O', 'X', 'X',
      ];
      expect(checkDraw(board, null)).toBe(false);
    });
  });

  describe('AI Minimax & Hint Engine', () => {
    it('AI takes immediate winning move', () => {
      const board: Board = ['X', 'X', null, 'O', 'O', null, null, null, null];
      const bestMove = getBestAIMove(board, 3, 'X', 'hard');
      expect(bestMove).toBe(2);
    });

    it('AI blocks immediate opponent win', () => {
      const board: Board = ['O', 'O', null, 'X', null, null, null, null, null];
      const bestMove = getBestAIMove(board, 3, 'X', 'hard');
      expect(bestMove).toBe(2);
    });

    it('Hint engine suggests valid empty cell', () => {
      const board: Board = createInitialBoard(3);
      board[0] = 'X';
      const hint = getHintMove(board, 3, 'O');
      expect(hint).toBeGreaterThanOrEqual(0);
      expect(hint).toBeLessThan(9);
      expect(board[hint]).toBeNull();
    });
  });
});
