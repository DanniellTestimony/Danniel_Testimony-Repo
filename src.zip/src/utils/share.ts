import type { Board, BoardSize, Player, PlayerProfile } from '../types/game';

export function generateShareResultText(
  board: Board,
  size: BoardSize,
  winner: Player | 'draw',
  p1: PlayerProfile,
  p2: PlayerProfile,
  movesCount: number,
  durationSeconds: number
): string {
  const title = "🎮 Olayode Daniel — Tic-Tac-Toe";
  const outcome =
    winner === 'draw'
      ? "🤝 Match Draw!"
      : `🏆 ${winner === p1.marker ? p1.name : p2.name} Wins (${winner})!`;

  const details = `📊 Size: ${size}x${size} | Moves: ${movesCount} | Time: ${durationSeconds}s`;

  let grid = '';
  for (let r = 0; r < size; r++) {
    let rowStr = '';
    for (let c = 0; c < size; c++) {
      const val = board[r * size + c];
      if (val === 'X') rowStr += '❌';
      else if (val === 'O') rowStr += '⭕';
      else rowStr += '⬜';
    }
    grid += rowStr + '\n';
  }

  const footer = "Play at: http://localhost:5173/ (Blue Brand Edition)";

  return `${title}\n${outcome}\n${details}\n\n${grid}\n${footer}`;
}
