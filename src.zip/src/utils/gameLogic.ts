import type { Board, BoardSize, Player, WinResult } from '../types/game';

// Helper to get win condition length (K) for given board size
export function getWinLength(size: BoardSize): number {
  if (size === 3) return 3;
  if (size === 4) return 4;
  return 4; // 4 in a row for 5x5 (popular Gomoku/Tic-Tac-Toe standard)
}

export function createInitialBoard(size: BoardSize): Board {
  return Array(size * size).fill(null);
}

// Generate all winning line combinations for any N x N board with K in a row
export function generateWinningCombinations(size: BoardSize): number[][] {
  const k = getWinLength(size);
  const combos: number[][] = [];

  // Rows
  for (let r = 0; r < size; r++) {
    for (let c = 0; c <= size - k; c++) {
      const line: number[] = [];
      for (let i = 0; i < k; i++) {
        line.push(r * size + (c + i));
      }
      combos.push(line);
    }
  }

  // Columns
  for (let c = 0; c < size; c++) {
    for (let r = 0; r <= size - k; r++) {
      const line: number[] = [];
      for (let i = 0; i < k; i++) {
        line.push((r + i) * size + c);
      }
      combos.push(line);
    }
  }

  // Diagonals (top-left to bottom-right)
  for (let r = 0; r <= size - k; r++) {
    for (let c = 0; c <= size - k; c++) {
      const line: number[] = [];
      for (let i = 0; i < k; i++) {
        line.push((r + i) * size + (c + i));
      }
      combos.push(line);
    }
  }

  // Anti-diagonals (top-right to bottom-left)
  for (let r = 0; r <= size - k; r++) {
    for (let c = k - 1; c < size; c++) {
      const line: number[] = [];
      for (let i = 0; i < k; i++) {
        line.push((r + i) * size + (c - i));
      }
      combos.push(line);
    }
  }

  return combos;
}

export function checkWinner(board: Board, size: BoardSize): WinResult {
  const combos = generateWinningCombinations(size);

  for (const line of combos) {
    const first = board[line[0]];
    if (first && line.every((idx) => board[idx] === first)) {
      const startIdx = line[0];
      const endIdx = line[line.length - 1];
      const startRow = Math.floor(startIdx / size);
      const startCol = startIdx % size;
      const endRow = Math.floor(endIdx / size);
      const endCol = endIdx % size;

      const cellSize = 100 / size;
      const x1 = startCol * cellSize + cellSize / 2;
      const y1 = startRow * cellSize + cellSize / 2;
      const x2 = endCol * cellSize + cellSize / 2;
      const y2 = endRow * cellSize + cellSize / 2;

      return {
        winner: first,
        winningCells: line,
        lineCoords: { x1, y1, x2, y2 },
      };
    }
  }

  return {
    winner: null,
    winningCells: [],
  };
}

export function checkDraw(board: Board, winner: Player | null): boolean {
  if (winner !== null) return false;
  return board.every((cell) => cell !== null);
}
