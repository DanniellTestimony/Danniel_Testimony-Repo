import type { Board, BoardSize, Player, AIDifficulty } from '../types/game';
import { checkWinner, generateWinningCombinations, getWinLength } from './gameLogic';

function minimax3x3(
  board: Board,
  depth: number,
  isMax: boolean,
  aiPlayer: Player,
  humanPlayer: Player,
  alpha: number,
  beta: number
): number {
  const result = checkWinner(board, 3);
  if (result.winner === aiPlayer) return 100 - depth;
  if (result.winner === humanPlayer) return depth - 100;
  if (board.every((c) => c !== null)) return 0;
  if (depth >= 7) return 0;

  const emptyIndices: number[] = [];
  board.forEach((val, idx) => {
    if (val === null) emptyIndices.push(idx);
  });

  if (isMax) {
    let maxEval = -Infinity;
    for (const idx of emptyIndices) {
      board[idx] = aiPlayer;
      const evalScore = minimax3x3(board, depth + 1, false, aiPlayer, humanPlayer, alpha, beta);
      board[idx] = null;
      maxEval = Math.max(maxEval, evalScore);
      alpha = Math.max(alpha, evalScore);
      if (beta <= alpha) break;
    }
    return maxEval;
  } else {
    let minEval = Infinity;
    for (const idx of emptyIndices) {
      board[idx] = humanPlayer;
      const evalScore = minimax3x3(board, depth + 1, true, aiPlayer, humanPlayer, alpha, beta);
      board[idx] = null;
      minEval = Math.min(minEval, evalScore);
      beta = Math.min(beta, evalScore);
      if (beta <= alpha) break;
    }
    return minEval;
  }
}

function evaluateHeuristicMove(
  board: Board,
  size: BoardSize,
  moveIndex: number,
  player: Player,
  opponent: Player
): number {
  const combos = generateWinningCombinations(size);
  const k = getWinLength(size);
  let score = 0;

  const row = Math.floor(moveIndex / size);
  const col = moveIndex % size;
  const center = (size - 1) / 2;
  const distFromCenter = Math.abs(row - center) + Math.abs(col - center);
  score += (size * 2 - distFromCenter) * 2;

  for (const line of combos) {
    if (!line.includes(moveIndex)) continue;

    let pCount = 0;
    let oppCount = 0;

    for (const idx of line) {
      const val = idx === moveIndex ? player : board[idx];
      if (val === player) pCount++;
      else if (val === opponent) oppCount++;
    }

    if (oppCount === 0) {
      if (pCount === k) score += 100000;
      else if (pCount === k - 1) score += 5000;
      else if (pCount === k - 2) score += 300;
      else score += 10;
    }

    let blockOppCount = 0;
    let blockPCount = 0;
    for (const idx of line) {
      const val = board[idx];
      if (val === opponent) blockOppCount++;
      else if (val === player) blockPCount++;
    }
    if (blockPCount === 0 && blockOppCount === k - 1) {
      score += 50000;
    } else if (blockPCount === 0 && blockOppCount === k - 2) {
      score += 1500;
    }
  }

  return score;
}

export function getBestAIMove(
  board: Board,
  size: BoardSize,
  aiPlayer: Player,
  difficulty: AIDifficulty = 'hard'
): number {
  const humanPlayer: Player = aiPlayer === 'X' ? 'O' : 'X';
  const emptyIndices: number[] = [];
  board.forEach((val, idx) => {
    if (val === null) emptyIndices.push(idx);
  });

  if (emptyIndices.length === 0) return -1;

  if (difficulty === 'easy') {
    if (Math.random() < 0.7) {
      return emptyIndices[Math.floor(Math.random() * emptyIndices.length)];
    }
  }

  if (difficulty === 'medium') {
    if (Math.random() < 0.35) {
      return emptyIndices[Math.floor(Math.random() * emptyIndices.length)];
    }
  }

  for (const idx of emptyIndices) {
    board[idx] = aiPlayer;
    const isWin = checkWinner(board, size).winner === aiPlayer;
    board[idx] = null;
    if (isWin) return idx;
  }

  for (const idx of emptyIndices) {
    board[idx] = humanPlayer;
    const isWin = checkWinner(board, size).winner === humanPlayer;
    board[idx] = null;
    if (isWin) return idx;
  }

  if (size === 3 && difficulty === 'hard') {
    let bestScore = -Infinity;
    let bestMove = emptyIndices[0];

    for (const idx of emptyIndices) {
      board[idx] = aiPlayer;
      const score = minimax3x3(board, 0, false, aiPlayer, humanPlayer, -Infinity, Infinity);
      board[idx] = null;
      if (score > bestScore) {
        bestScore = score;
        bestMove = idx;
      }
    }
    return bestMove;
  }

  let bestScore = -Infinity;
  let bestMove = emptyIndices[0];

  for (const idx of emptyIndices) {
    const score = evaluateHeuristicMove(board, size, idx, aiPlayer, humanPlayer);
    if (score > bestScore) {
      bestScore = score;
      bestMove = idx;
    }
  }

  return bestMove;
}

export function getHintMove(board: Board, size: BoardSize, player: Player): number {
  return getBestAIMove(board, size, player, 'hard');
}
